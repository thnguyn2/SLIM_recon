
for i=1:length(x)-9
    
        a(i,1)=((x(i)+x(i+1)+x(i+2)+x(i+3)+x(i+4)+x(i+5)+x(i+6)+x(i+7)+x(i+8)+x(i+9))/10);
        
      
end
%        for i=1:length(x)-9
%            b(i,1)=a(i+10)-a(i);
%        end
%        